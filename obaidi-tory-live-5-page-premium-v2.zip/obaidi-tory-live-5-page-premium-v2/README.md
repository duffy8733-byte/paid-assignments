# Obaidi Tory — Premium 5-Page Portfolio v2

Includes a larger 3D centerpiece, stronger depth, glass effects, and smoother animation.

Pages:
- index.html
- about.html
- services.html
- projects.html
- contact.html
- privacy.html

Shared:
- style.css
- script.js

Keep all files together in the repository root.
