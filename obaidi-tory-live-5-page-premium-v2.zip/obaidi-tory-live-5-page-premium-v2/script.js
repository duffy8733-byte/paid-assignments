
const scene=document.querySelector(".scene");
const device=document.querySelector(".device");
let rx=-10,ry=-18,drag=false,lx=0,ly=0;

function render(){
  if(device) device.style.transform=`rotateX(${rx}deg) rotateY(${ry}deg)`;
}

if(scene&&device){
  scene.addEventListener("pointerdown",e=>{
    drag=true;lx=e.clientX;ly=e.clientY;scene.setPointerCapture(e.pointerId);
  });
  scene.addEventListener("pointermove",e=>{
    if(!drag)return;
    ry+=(e.clientX-lx)*.3;
    rx-=(e.clientY-ly)*.24;
    rx=Math.max(-50,Math.min(50,rx));
    lx=e.clientX;ly=e.clientY;
    render();
  });
  scene.addEventListener("pointerup",()=>drag=false);
  scene.addEventListener("pointercancel",()=>drag=false);
}

const revealItems=document.querySelectorAll(".reveal");
if("IntersectionObserver" in window){
  const observer=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting) entry.target.classList.add("visible");
    });
  },{threshold:.12});
  revealItems.forEach(item=>observer.observe(item));
}else{
  revealItems.forEach(item=>item.classList.add("visible"));
}
render();
